﻿namespace SalaoT2.Dominio
{
    internal class a
    {
        internal static object ServicoSolicitado;
        internal static object servicoSolicitadoServicoPreco;
        internal static object statusAgenda;

        public static object StatusAgenda { get; internal set; }
        public static object ServicoPreco { get; internal set; }
    }
}